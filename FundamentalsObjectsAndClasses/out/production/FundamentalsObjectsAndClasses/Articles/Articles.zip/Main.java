import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] articleData = scanner.nextLine().split(", ");
        String currentTitle = articleData[0];
        String currentContent = articleData[1];
        String currentAuthor = articleData[2];
        Articles articles = new Articles(currentTitle, currentContent, currentAuthor);

        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < n; i++) {
            String[] tokens = scanner.nextLine().split(": ");
            String command = tokens[0];
            String data = tokens[1];
            switch (command) {
                case "Edit":
                    articles.edit(data);
                    break;
                case "ChangeAuthor":
                articles.changeAuthor(data);
                    break;
                case "Rename":
                    articles.rename(data);
                    break;
            }
        }
        System.out.println(articles);
    }
}
